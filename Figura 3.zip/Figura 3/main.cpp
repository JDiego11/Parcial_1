#include <iostream>

void ParPrint(bool Matriz[10][10], int Dimension, int i);
void ImparPrint(bool Matriz[10][10], int Dimension, int i);

int main() {
    bool Matriz[10][10];
    int Dimension = 10;

    //ParPrint(Matriz, Dimension);
    //ImparPrint(Matriz, Dimension);

    //Funcion que alterne las filas//
    for (int i = 0; i < Dimension; i ++){
        if ((i/2) % 2 == 0 ){
            ParPrint (Matriz, Dimension, i);
        }else{
            ImparPrint(Matriz, Dimension, i);
        }
    }
    // Imprimir la matriz
    for (int i = 0; i < Dimension; i++) {
        for (int j = 0; j < Dimension; j++) {
            std::cout << Matriz[i][j] << " ";
        }
        std::cout << std::endl;
    }

    return 0;
}

void ParPrint(bool Matriz[10][10], int Dimension, int i) {
    int pos;
        pos = 2;
        for (int k = 0; k < Dimension; k++) {
            if (i - i + k == pos) {
                Matriz[i][k] = false;
                pos += 3;
            } else {
                Matriz[i][k] = true;
            }
        }
    }

void ImparPrint(bool Matriz[10][10], int Dimension, int i){
        for (int k = 0; k < Dimension; k++) {
            if (i - i + k % 3 == 0) {
                Matriz[i][k] = false;
            } else {
                Matriz[i][k] = true;
            }
        }
}
