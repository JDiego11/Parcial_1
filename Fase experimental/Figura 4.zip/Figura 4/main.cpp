#include <iostream>

using namespace std;

void UpPart(bool Matriz[20][20], int, int, int );
void LowPart(bool Matriz[20][20], int, int, int);

int main()
{
    bool Matriz[20][20];
    int Dimension = 20;

     // Parte arriba//
    for (int i = 0; i < Dimension; i++){
        for (int k = 0; k < Dimension; k++){
            if (i < Dimension/2){
                UpPart(Matriz, Dimension, i, k);
            }else{
                LowPart(Matriz, Dimension, i, k);
            }
        }
    }


    // Imprimir la matriz
    for (int i = 0; i < Dimension; i++) {
        for (int j = 0; j < Dimension; j++) {
            std::cout << Matriz[i][j] << " ";
        }
        std::cout << std::endl;
    }
}

void UpPart(bool Matriz[20][20], int Dimension, int i, int k){
    if (k - i < 0 or  k - i > Dimension/2 - 1){
        Matriz[i][k] = false;
    }else{
        Matriz[i][k] = true;
    }
}
void LowPart(bool Matriz[20][20], int Dimension, int i, int k){
    if (k+i < Dimension - 1 or k + i > Dimension + (Dimension/2) - 2){
        Matriz[i][k] = false;
    }else{
        Matriz[i][k] = true;
    }
}

